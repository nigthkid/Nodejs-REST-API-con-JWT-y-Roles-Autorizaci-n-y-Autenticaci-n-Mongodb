export const createUser = (req, res) => {
    res.json('creating user')
}