import app from "./app"
import './database'

app.listen(4000);

console.log('Server Listen on port', 4000)