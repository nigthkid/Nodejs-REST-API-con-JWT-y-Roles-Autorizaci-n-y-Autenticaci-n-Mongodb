import {Router} from 'express'
const router = Router()

import * as producstCtrl from '../controllers/products.controller'
import { authJwt } from '../middlewares'

router.post('/', [authJwt.verifyToken, authJwt.isModerator ], producstCtrl.createProduct)

router.get('/', producstCtrl.getProducts)

router.get('/:productId', producstCtrl.getProductById)

router.put('/:productId', [authJwt.verifyToken, authJwt.isAdmin ], producstCtrl.updateProductById)

router.delete('/:productId', [authJwt.verifyToken, authJwt.isAdmin ], producstCtrl.deleteProductById)

export default router;