export default {
    SECRET: 'products-api'
}